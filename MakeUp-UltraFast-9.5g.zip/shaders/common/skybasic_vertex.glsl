#include "/lib/config.glsl"

/* Color utils */

#if MC_VERSION < 11604
    #ifdef THE_END
        #include "/lib/color_utils_end.glsl"
    #elif defined NETHER
        #include "/lib/color_utils_nether.glsl"
    #else
        #include "/lib/color_utils.glsl"
    #endif
#endif

/* Uniforms */

uniform mat4 gbufferModelView;

#if MC_VERSION < 11604
    uniform float rainStrength;
#endif

/* Ins / Outs */

#if MC_VERSION < 11604
    varying vec3 upVector;
    varying vec3 zenithSkyColor;
    varying vec3 horizonSkyColor;
#endif

varying vec4 star_data;

#ifdef GAMEOVERSE_MOD_SKY
    varying vec4 goColor;
    varying float goOnSphere;
#endif

/* Utility functions */

#if AA_TYPE > 0
    #include "/src/taa_offset.glsl"
#endif

#if MC_VERSION < 11604
    #include "/lib/luma.glsl"
#endif

// MAIN FUNCTION ------------------

void main() {
    gl_Position = gl_ModelViewProjectionMatrix * gl_Vertex;

    #if AA_TYPE > 0
        gl_Position.xy += taaOffset * gl_Position.w;
    #endif

    #ifdef GAMEOVERSE_MOD_SKY
        goColor = gl_Color;
        // 1 for a vertex on Spyglass Astronomy's 100-block sky sphere. Interpolated, it stays 1 only
        // across triangles whose corners all sit on it (planets, constellation lines); 26.1's sky
        // disc and void disc have vertices inside that radius too, but their centres are far off it.
        goOnSphere = float(abs(length(gl_Vertex.xyz) - 100.0) < 1.0);
    #endif

    #if !defined THE_END
        star_data = vec4(
            float(gl_Color.r == gl_Color.g &&
            gl_Color.g == gl_Color.b &&
            gl_Color.r > 0.0) * gl_Color.r
        );
    #else
        star_data = vec4(0.0);
    #endif

    #if MC_VERSION < 11604
        upVector = normalize(gbufferModelView[1].xyz);

        #include "/src/hi_sky.glsl"
        #include "/src/low_sky.glsl"
    #endif
}
